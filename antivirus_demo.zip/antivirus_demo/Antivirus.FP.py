import os
import time
import logging


sandbox = "sandbox_vm"
os.makedirs(sandbox, exist_ok=True)

honeyfiles = ["senha.txt", "dados_banco.xlsx", "chave_api.key"]

for f in honeyfiles:
    path = os.path.join(sandbox, f)
    if not os.path.exists(path):
        with open(path, "w") as file:
            file.write("ARQUIVO ISCA - ACESSO SUSPEITO\n")

print("Sandbox e Honeyfiles criados com sucesso!")

logging.basicConfig(
    filename="monitoramento.log",
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

def monitorar():
    print("\nMonitoramento iniciado (Ctrl+C para parar)...")

    timestamps = {}
    for f in honeyfiles:
        path = os.path.join(sandbox, f)
        if os.path.exists(path):
            timestamps[f] = os.path.getmtime(path)
        else:
            timestamps[f] = None

    try:
        while True:
            time.sleep(2)
            for f in honeyfiles:
                path = os.path.join(sandbox, f)

                if not os.path.exists(path):
                    if timestamps[f] is not None:
                        msg = f"[ALERTA] O arquivo {f} foi DELETADO!"
                        print(msg)
                        logging.warning(msg)
                        timestamps[f] = None
                else:
                    new_time = os.path.getmtime(path)
                    if timestamps[f] is None:
                        msg = f"[ALERTA] O arquivo {f} foi CRIADO novamente!"
                        print(msg)
                        logging.warning(msg)
                    elif new_time != timestamps[f]:
                        msg = f"[ALERTA] O arquivo {f} foi MODIFICADO!"
                        print(msg)
                        logging.warning(msg)
                    timestamps[f] = new_time

    except KeyboardInterrupt:
        print("\nMonitoramento encerrado.")
        logging.info("Monitoramento encerrado.")

monitorar()
